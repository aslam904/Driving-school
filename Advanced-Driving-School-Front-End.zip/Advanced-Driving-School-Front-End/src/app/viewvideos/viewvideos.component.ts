import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewvideos',
  templateUrl: './viewvideos.component.html',
  styleUrls: ['./viewvideos.component.css']
})
export class ViewvideosComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
